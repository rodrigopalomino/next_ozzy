// app/admin/productos/[id]/page.tsx
"use client";

import * as React from "react";
import { useParams } from "next/navigation";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { useProducto } from "@/hooks/productoo/useProducto";
import { useProductoImagenPresign } from "@/hooks/useProductoImagenPresign";
import { useCreateProductoImagen } from "@/hooks/useCreateProductoImagen";
import { useDeleteProductoImagen } from "@/hooks/useDeleteProductoImagen";
import { useCategorias } from "@/hooks/categoria/useCategorias";
import { useColecciones } from "@/hooks/coleccion/useColecciones";
import { useInsignias } from "@/hooks/insignia/useInsignias";
import { useTallas } from "@/hooks/talla/useTallas";
import { useColores } from "@/hooks/color/useColores";

type EstadoProducto = "ACTIVO" | "OCULTO" | "ARCHIVADO";
type PlataformaVideo = "INSTAGRAM" | "TIKTOK";

export default function Page() {
  const params = useParams<{ id: string }>();
  const id = params?.id;

  const { data: producto, isLoading, isError } = useProducto(id);

  const { data: cats = [] } = useCategorias();
  const { data: cols = [] } = useColecciones();
  const { data: badges = [] } = useInsignias();
  const { data: tallas = [] } = useTallas();
  const { data: colores = [] } = useColores();

  // =================
  // UI state (vacío al inicio)
  // =================
  const [nombre, setNombre] = React.useState("");
  const [slug, setSlug] = React.useState("");
  const [descripcion, setDescripcion] = React.useState("");
  const [estado, setEstado] = React.useState<EstadoProducto>("ACTIVO");
  const [precioBase, setPrecioBase] = React.useState<string>("");

  // precio/oferta (puede venir null)
  const [precioOriginal, setPrecioOriginal] = React.useState<string>("");
  const [porcentajeDescuento, setPorcentajeDescuento] =
    React.useState<string>("0");
  const [precioOferta, setPrecioOferta] = React.useState<string>("");
  const [iniciaEn, setIniciaEn] = React.useState<string>("");
  const [terminaEn, setTerminaEn] = React.useState<string>("");
  const [precioActivo, setPrecioActivo] = React.useState<boolean>(false);

  // relaciones (mock checkboxes) -> siguen estáticas
  const [selectedCatIds, setSelectedCatIds] = React.useState<string[]>([]);
  const [selectedColIds, setSelectedColIds] = React.useState<string[]>([]);
  const [selectedBadgeIds, setSelectedBadgeIds] = React.useState<string[]>([]);

  // video form mock
  const [videoPlataforma, setVideoPlataforma] =
    React.useState<PlataformaVideo>("INSTAGRAM");
  const [videoUrl, setVideoUrl] = React.useState("");
  const [videoEtiqueta, setVideoEtiqueta] = React.useState("");
  const [videoOrden, setVideoOrden] = React.useState<string>("0");

  // variant form mock
  const [variantTallaId, setVariantTallaId] = React.useState<string>("");
  const [variantColorId, setVariantColorId] = React.useState<string>("");
  const [variantSku, setVariantSku] = React.useState<string>("");
  const [variantPrecio, setVariantPrecio] = React.useState<string>("");
  const [variantStock, setVariantStock] = React.useState<string>("");
  const [variantActivo, setVariantActivo] = React.useState<boolean>(true);

  // =================
  // ✅ Cuando llegue producto, llenar UI state
  // =================
  React.useEffect(() => {
    if (!producto) return;

    setNombre(producto.nombre ?? "");
    setSlug(producto.slug ?? "");
    setDescripcion(producto.descripcion ?? "");
    setEstado((producto.estado as EstadoProducto) ?? "ACTIVO");
    setPrecioBase(
      producto.precioBase == null ? "" : String(producto.precioBase),
    );

    // precio/oferta
    if (producto.precio) {
      setPrecioOriginal(String(producto.precio.precioOriginal ?? ""));
      setPorcentajeDescuento(String(producto.precio.porcentajeDescuento ?? 0));
      setPrecioOferta(
        producto.precio.precioOferta == null
          ? ""
          : String(producto.precio.precioOferta),
      );
      setIniciaEn(producto.precio.iniciaEn ?? "");
      setTerminaEn(producto.precio.terminaEn ?? "");
      setPrecioActivo(Boolean(producto.precio.activo));
    } else {
      setPrecioOriginal("");
      setPorcentajeDescuento("0");
      setPrecioOferta("");
      setIniciaEn("");
      setTerminaEn("");
      setPrecioActivo(false);
    }

    // relaciones (si tu backend devuelve arrays de objetos, acá solo set vacío por ahora)
    // Si luego quieres mapear ids reales, lo haces cuando tengas endpoints de catálogo.
    setSelectedCatIds([]);
    setSelectedColIds([]);
    setSelectedBadgeIds([]);
  }, [producto]);

  // =================
  // Guards
  // =================
  if (isLoading) {
    return <div className="mx-auto w-full max-w-5xl p-6">Cargando...</div>;
  }
  if (isError || !producto) {
    return (
      <div className="mx-auto w-full max-w-5xl p-6">Producto no encontrado</div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-5xl space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
        <div className="space-y-1">
          <h1 className="text-2xl font-semibold tracking-tight">
            Editar producto
          </h1>
          <p className="text-sm text-muted-foreground">
            {producto.nombre} •{" "}
            <span className="font-medium">{producto.slug}</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline">Ver en tienda</Button>
          <Button variant="destructive">Archivar</Button>
        </div>
      </div>

      <Tabs defaultValue="general" className="w-full">
        <TabsList className="flex w-full flex-wrap justify-start gap-2">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="price">Precio / Oferta</TabsTrigger>
          <TabsTrigger value="images">Imágenes</TabsTrigger>
          <TabsTrigger value="videos">Videos</TabsTrigger>
          <TabsTrigger value="variants">Variantes</TabsTrigger>
          <TabsTrigger value="relations">Relaciones</TabsTrigger>
        </TabsList>

        {/* ========== GENERAL ========== */}
        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Información</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="grid gap-2">
                <Label>Nombre</Label>
                <Input
                  value={nombre}
                  onChange={(e) => setNombre(e.target.value)}
                />
              </div>

              <div className="grid gap-2">
                <Label>Slug</Label>
                <Input value={slug} onChange={(e) => setSlug(e.target.value)} />
                <p className="text-xs text-muted-foreground">
                  URL pública:{" "}
                  <span className="font-medium">/producto/{slug || "..."}</span>
                </p>
              </div>

              <div className="grid gap-2">
                <Label>Descripción</Label>
                <Textarea
                  value={descripcion}
                  onChange={(e) => setDescripcion(e.target.value)}
                  rows={5}
                />
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div className="grid gap-2">
                  <Label>Estado</Label>
                  <Select
                    value={estado}
                    onValueChange={(v) => setEstado(v as EstadoProducto)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona estado" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ACTIVO">ACTIVO</SelectItem>
                      <SelectItem value="OCULTO">OCULTO</SelectItem>
                      <SelectItem value="ARCHIVADO">ARCHIVADO</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <Label>Precio base (opcional)</Label>
                  <Input
                    inputMode="decimal"
                    placeholder="Ej: 129.90"
                    value={precioBase}
                    onChange={(e) => setPrecioBase(e.target.value)}
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button>Guardar cambios</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== PRECIO / OFERTA ========== */}
        <TabsContent value="price" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Precio y oferta</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                <div className="grid gap-2">
                  <Label>Precio original</Label>
                  <Input
                    value={precioOriginal}
                    onChange={(e) => setPrecioOriginal(e.target.value)}
                  />
                </div>

                <div className="grid gap-2">
                  <Label>% Descuento</Label>
                  <Input
                    value={porcentajeDescuento}
                    onChange={(e) => setPorcentajeDescuento(e.target.value)}
                  />
                </div>

                <div className="grid gap-2">
                  <Label>Precio oferta (opcional)</Label>
                  <Input
                    value={precioOferta}
                    onChange={(e) => setPrecioOferta(e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div className="grid gap-2">
                  <Label>Inicia (datetime)</Label>
                  <Input
                    value={iniciaEn}
                    onChange={(e) => setIniciaEn(e.target.value)}
                  />
                </div>
                <div className="grid gap-2">
                  <Label>Termina (datetime)</Label>
                  <Input
                    value={terminaEn}
                    onChange={(e) => setTerminaEn(e.target.value)}
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  className="accent-pink-500"
                  checked={precioActivo}
                  onChange={(e) => setPrecioActivo(e.target.checked)}
                />
                <span>Oferta activa</span>
              </div>

              <div className="flex flex-wrap items-center justify-end gap-2">
                <Button variant="outline">Eliminar precio/oferta</Button>
                <Button>Guardar oferta</Button>
              </div>

              <Separator />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== IMÁGENES ========== */}
        <TabsContent value="images" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Imágenes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <ImageManagerShopifyLike
                productoId={id}
                initial={(producto.imagenes ?? []).map((img) => ({
                  id: img.id,
                  previewUrl: img.url,
                  alt: img.alt ?? "",
                  tipo: (img.tipo === "principal" ? "principal" : "galeria") as
                    | "principal"
                    | "galeria",
                  orden: img.orden ?? 0,
                }))}
              />
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== VIDEOS ========== */}
        <TabsContent value="videos" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Videos</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="rounded-md border p-4 space-y-3">
                <div className="text-sm font-medium">Agregar video (mock)</div>

                <div className="grid gap-3 md:grid-cols-3">
                  <div className="grid gap-2">
                    <Label>Plataforma</Label>
                    <Select
                      value={videoPlataforma}
                      onValueChange={(v) =>
                        setVideoPlataforma(v as PlataformaVideo)
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="INSTAGRAM">INSTAGRAM</SelectItem>
                        <SelectItem value="TIKTOK">TIKTOK</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2 md:col-span-2">
                    <Label>URL</Label>
                    <Input
                      value={videoUrl}
                      onChange={(e) => setVideoUrl(e.target.value)}
                      placeholder="https://..."
                    />
                  </div>
                </div>

                <div className="grid gap-3 md:grid-cols-3">
                  <div className="grid gap-2 md:col-span-2">
                    <Label>Etiqueta (opcional)</Label>
                    <Input
                      value={videoEtiqueta}
                      onChange={(e) => setVideoEtiqueta(e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>Orden</Label>
                    <Input
                      value={videoOrden}
                      onChange={(e) => setVideoOrden(e.target.value)}
                    />
                  </div>
                </div>

                <Button>Agregar video</Button>
              </div>

              <div className="space-y-3">
                <div className="text-sm font-medium">Lista</div>

                {(producto.videos ?? []).length ? (
                  <div className="grid gap-3">
                    {producto.videos.map((v) => (
                      <div
                        key={v.id}
                        className="flex items-center gap-3 rounded-md border p-3"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="text-sm font-medium">
                            {v.plataforma} • orden {v.orden}
                          </div>
                          <div className="truncate text-xs text-muted-foreground">
                            {v.url}
                          </div>
                          {v.etiqueta ? (
                            <div className="text-xs">{v.etiqueta}</div>
                          ) : null}
                        </div>
                        <Button variant="destructive">Eliminar</Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground">
                    Aún no hay videos.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== VARIANTES ========== */}
        <TabsContent value="variants" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Variantes (talla + color)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="rounded-md border p-4 space-y-3">
                <div className="text-sm font-medium">Crear variante (mock)</div>

                <div className="grid gap-3 md:grid-cols-2">
                  <div className="grid gap-2">
                    <Label>Talla</Label>
                    <Select
                      value={variantTallaId}
                      onValueChange={setVariantTallaId}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecciona" />
                      </SelectTrigger>
                      <SelectContent>
                        {tallas.map((t) => (
                          <SelectItem key={t.id} value={t.id}>
                            {t.etiqueta}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid gap-2">
                    <Label>Color</Label>
                    <Select
                      value={variantColorId}
                      onValueChange={setVariantColorId}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecciona" />
                      </SelectTrigger>
                      <SelectContent>
                        {colores.map((c) => (
                          <SelectItem key={c.id} value={c.id}>
                            {c.nombre}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid gap-3 md:grid-cols-3">
                  <div className="grid gap-2">
                    <Label>SKU (opcional)</Label>
                    <Input
                      value={variantSku}
                      onChange={(e) => setVariantSku(e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>Precio (opcional)</Label>
                    <Input
                      value={variantPrecio}
                      onChange={(e) => setVariantPrecio(e.target.value)}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label>Stock (opcional)</Label>
                    <Input
                      value={variantStock}
                      onChange={(e) => setVariantStock(e.target.value)}
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    className="accent-pink-500"
                    checked={variantActivo}
                    onChange={(e) => setVariantActivo(e.target.checked)}
                  />
                  <span>Activa</span>
                </div>

                <Button>Agregar variante</Button>
              </div>

              <div className="space-y-3">
                <div className="text-sm font-medium">Lista</div>
                {(producto.variantes ?? []).length ? (
                  <div className="grid gap-3">
                    {producto.variantes.map((v) => (
                      <div
                        key={v.id}
                        className="flex items-center gap-3 rounded-md border p-3"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="text-sm font-medium">
                            {v.talla?.etiqueta} • {v.color?.nombre} •{" "}
                            {v.activo ? "Activa" : "Inactiva"}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            SKU: {v.sku ?? "—"} • Precio: {v.precio ?? "—"} •
                            Stock: {v.stock ?? "—"}
                          </div>
                        </div>
                        <Button variant="destructive">Eliminar</Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground">
                    Aún no hay variantes.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ========== RELACIONES ========== */}
        <TabsContent value="relations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Categorías, Colecciones, Insignias</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-6 md:grid-cols-3">
                <div className="space-y-3">
                  <div className="text-sm font-medium">Categorías</div>
                  <div className="max-h-64 space-y-2 overflow-auto rounded-md border p-3">
                    {cats.map((c) => {
                      const checked = selectedCatIds.includes(c.id);
                      return (
                        <label
                          key={c.id}
                          className="flex items-center gap-2 text-sm"
                        >
                          <input
                            type="checkbox"
                            className="accent-pink-500"
                            checked={checked}
                            onChange={(e) => {
                              setSelectedCatIds((prev) =>
                                e.target.checked
                                  ? [...prev, c.id]
                                  : prev.filter((x) => x !== c.id),
                              );
                            }}
                          />
                          <span>{c.nombre}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="text-sm font-medium">Colecciones</div>
                  <div className="max-h-64 space-y-2 overflow-auto rounded-md border p-3">
                    {cols.map((c) => {
                      const checked = selectedColIds.includes(c.id);
                      return (
                        <label
                          key={c.id}
                          className="flex items-center gap-2 text-sm"
                        >
                          <input
                            type="checkbox"
                            className="accent-pink-500"
                            checked={checked}
                            onChange={(e) => {
                              setSelectedColIds((prev) =>
                                e.target.checked
                                  ? [...prev, c.id]
                                  : prev.filter((x) => x !== c.id),
                              );
                            }}
                          />
                          <span>{c.nombre}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="text-sm font-medium">Insignias</div>
                  <div className="max-h-64 space-y-2 overflow-auto rounded-md border p-3">
                    {badges.map((b) => {
                      const checked = selectedBadgeIds.includes(b.id);
                      return (
                        <label
                          key={b.id}
                          className="flex items-center gap-2 text-sm"
                        >
                          <input
                            type="checkbox"
                            className="accent-pink-500"
                            checked={checked}
                            onChange={(e) => {
                              setSelectedBadgeIds((prev) =>
                                e.target.checked
                                  ? [...prev, b.id]
                                  : prev.filter((x) => x !== b.id),
                              );
                            }}
                          />
                          <span>{b.nombre}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div className="flex justify-end">
                <Button>Guardar relaciones</Button>
              </div>

              <Separator />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

/** =========================
 * Shopify-like Image Manager (UI ONLY)
 * ========================= */
/** =========================
 * Shopify-like Image Manager (UPLOAD + CREATE + DELETE)
 * ========================= */
function ImageManagerShopifyLike({
  productoId,
  initial,
}: {
  productoId: string;
  initial: Array<{
    id: string;
    previewUrl: string;
    alt: string;
    tipo: "principal" | "galeria";
    orden: number;
  }>;
}) {
  type Img = {
    id: string; // id (si es de BD) o tempId (si es local)
    imagenId?: string; // id real en BD (cuando ya se creó)
    file?: File;
    previewUrl: string;
    alt: string;
    tipo: "principal" | "galeria";
    orden: number;
    status?: "idle" | "uploading" | "done" | "error";
    errorMsg?: string;
  };

  const { mutateAsync: presignAsync } = useProductoImagenPresign(productoId);
  const { mutateAsync: createAsync, isPending: isCreating } =
    useCreateProductoImagen(productoId);
  const { mutateAsync: deleteAsync, isPending: isDeleting } =
    useDeleteProductoImagen(productoId);

  const inputRef = React.useRef<HTMLInputElement | null>(null);
  const [dragOver, setDragOver] = React.useState(false);

  // items = UI local (mezcla imágenes existentes + subidas localmente)
  const [items, setItems] = React.useState<Img[]>(() =>
    initial
      .slice()
      .sort((a, b) => a.orden - b.orden)
      .map((x, i) => ({
        id: x.id,
        imagenId: x.id,
        previewUrl: x.previewUrl,
        alt: x.alt ?? "",
        tipo: x.tipo,
        orden: i,
        status: "done",
      })),
  );

  // cuando cambia initial (por invalidateQueries), sincroniza
  React.useEffect(() => {
    setItems(
      initial
        .slice()
        .sort((a, b) => a.orden - b.orden)
        .map((x, i) => ({
          id: x.id,
          imagenId: x.id,
          previewUrl: x.previewUrl,
          alt: x.alt ?? "",
          tipo: x.tipo,
          orden: i,
          status: "done",
        })),
    );
  }, [initial]);

  // limpiar blobs
  React.useEffect(() => {
    return () => {
      items.forEach((i) => {
        if (i.previewUrl.startsWith("blob:")) URL.revokeObjectURL(i.previewUrl);
      });
    };
  }, [items]);

  function openPicker() {
    inputRef.current?.click();
  }

  function nextOrdenBase() {
    // orden local (UI). En backend idealmente lo controla un endpoint update,
    // aquí hacemos un "best effort" al crear.
    return items.length;
  }

  async function uploadAndCreateOne(file: File, tipo: "principal" | "galeria") {
    // 1) presign
    const presign = await presignAsync({
      filename: file.name,
      contentType: file.type || "application/octet-stream",
    });

    // 2) PUT a MinIO
    const res = await fetch(presign.uploadUrl, {
      method: "PUT",
      body: file,
      headers: {
        "Content-Type": file.type || "application/octet-stream",
      },
    });

    if (!res.ok) {
      throw new Error(`Error subiendo archivo (HTTP ${res.status})`);
    }

    // 3) crear registro en BD
    const publicUrl = presign.url; // <- tu backend devuelve "url"

    if (!publicUrl || typeof publicUrl !== "string" || publicUrl.length < 5) {
      throw new Error("Presign no devolvió una URL válida");
    }

    await createAsync({
      url: publicUrl,
      alt: "",
      orden: nextOrdenBase(),
      tipo,
    });
  }

  async function addFiles(files: FileList | File[]) {
    const arr = Array.from(files);
    if (!arr.length) return;

    // ¿ya existe principal en BD/initial?
    const hasPrincipal = items.some((x) => x.tipo === "principal");

    // primero, pinta previews locales "uploading"
    const tempToAdd: Img[] = arr.map((f, idx) => {
      const tempId = crypto.randomUUID();
      const willBePrincipal = !hasPrincipal && idx === 0; // primera subida se vuelve principal si no hay
      return {
        id: tempId,
        file: f,
        previewUrl: URL.createObjectURL(f),
        alt: "",
        tipo: willBePrincipal ? "principal" : "galeria",
        orden: 0,
        status: "uploading",
      };
    });

    setItems((prev) => {
      const merged = [...prev, ...tempToAdd];
      // ordena: principal primero, luego por orden
      const next = merged
        .slice()
        .sort((a, b) => (a.tipo === "principal" ? -1 : 1));
      return next.map((x, i) => ({ ...x, orden: i }));
    });

    // luego sube + crea en BD (secuencial para evitar reventar server)
    for (const img of tempToAdd) {
      try {
        await uploadAndCreateOne(img.file!, img.tipo);

        // al crear, react-query invalida y el producto recarga.
        // Marcamos como done localmente mientras llega el refresh
        setItems((prev) =>
          prev.map((x) => (x.id === img.id ? { ...x, status: "done" } : x)),
        );
      } catch (e: any) {
        setItems((prev) =>
          prev.map((x) =>
            x.id === img.id
              ? {
                  ...x,
                  status: "error",
                  errorMsg: e?.message || "Error subiendo imagen",
                }
              : x,
          ),
        );
      }
    }
  }

  function onDrop(e: React.DragEvent<HTMLDivElement>) {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files?.length) addFiles(e.dataTransfer.files);
  }

  // UI ONLY: sin endpoint update, esto no persiste.
  function setPrincipalUI(id: string) {
    setItems((prev) => {
      let next = prev.map((x) =>
        x.id === id ? { ...x, tipo: "principal" } : { ...x, tipo: "galeria" },
      );
      next.sort((a, b) => (a.tipo === "principal" ? -1 : 1));
      return next.map((x, i) => ({ ...x, orden: i }));
    });
  }

  // UI ONLY: sin endpoint update, esto no persiste.
  function moveUI(id: string, dir: -1 | 1) {
    setItems((prev) => {
      const ordered = prev.slice().sort((a, b) => a.orden - b.orden);
      const idx = ordered.findIndex((x) => x.id === id);
      if (idx < 0) return prev;

      const swapIdx = idx + dir;
      if (swapIdx < 0 || swapIdx >= ordered.length) return prev;

      // no permitir mover algo por encima del principal (solo UI)
      if (
        ordered[idx].tipo !== "principal" &&
        ordered[swapIdx].tipo === "principal"
      ) {
        return prev;
      }

      const next = ordered.slice();
      const tmp = next[idx];
      next[idx] = next[swapIdx];
      next[swapIdx] = tmp;

      return next.map((x, i) => ({ ...x, orden: i }));
    });
  }

  async function remove(img: Img) {
    // si es local blob y no existe en BD, solo quita UI
    if (!img.imagenId) {
      if (img.previewUrl.startsWith("blob:"))
        URL.revokeObjectURL(img.previewUrl);
      setItems((prev) => {
        const next = prev.filter((x) => x.id !== img.id);
        return next.map((x, i) => ({ ...x, orden: i }));
      });
      return;
    }

    // si existe en BD, llama delete hook
    await deleteAsync(img.imagenId);
    // invalidateQueries lo hará el hook, initial cambiará y se sincroniza solo
  }

  function setAltUI(id: string, alt: string) {
    // UI ONLY (sin endpoint update)
    setItems((prev) => prev.map((x) => (x.id === id ? { ...x, alt } : x)));
  }

  const ordered = items.slice().sort((a, b) => a.orden - b.orden);

  const busy = isCreating || isDeleting;

  return (
    <div className="space-y-4">
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) addFiles(e.target.files);
          e.currentTarget.value = "";
        }}
      />

      <div className="flex items-center justify-between gap-3">
        <div className="space-y-0.5">
          <div className="text-sm font-medium">Media</div>
          <div className="text-xs text-muted-foreground">
            Sube imágenes (MinIO), marca principal (UI) y elimina.
          </div>
        </div>

        <Button type="button" onClick={openPicker} disabled={busy}>
          Agregar imágenes
        </Button>
      </div>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={onDrop}
        className={[
          "rounded-lg border border-dashed p-6 transition",
          dragOver ? "bg-muted" : "bg-background",
        ].join(" ")}
      >
        <div className="text-sm font-medium">Arrastra y suelta aquí</div>
        <div className="text-xs text-muted-foreground">
          o usa “Agregar imágenes”. PNG, JPG, WEBP.
        </div>
      </div>

      {ordered.length ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {ordered.map((img) => (
            <div key={img.id} className="rounded-lg border p-3 space-y-3">
              <div className="relative overflow-hidden rounded-md border bg-white">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={img.previewUrl}
                  alt={img.alt}
                  className="h-48 w-full object-cover"
                />

                {img.tipo === "principal" ? (
                  <div className="absolute left-2 top-2 rounded-full bg-black/80 px-2 py-1 text-xs text-white">
                    Principal
                  </div>
                ) : null}

                {img.status === "uploading" ? (
                  <div className="absolute inset-0 grid place-items-center bg-black/40 text-xs text-white">
                    Subiendo...
                  </div>
                ) : null}

                {img.status === "error" ? (
                  <div className="absolute inset-0 grid place-items-center bg-red-600/60 px-2 text-center text-xs text-white">
                    {img.errorMsg ?? "Error"}
                  </div>
                ) : null}
              </div>

              <div className="grid gap-2">
                <Label className="text-xs">Alt (UI por ahora)</Label>
                <Input
                  value={img.alt}
                  onChange={(e) => setAltUI(img.id, e.target.value)}
                  placeholder="Ej: Foto frontal"
                  disabled={img.status === "uploading" || busy}
                />
                <p className="text-[11px] text-muted-foreground">
                  Para guardar Alt/Orden/Principal en BD te falta un endpoint
                  update (si quieres te lo armo).
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setPrincipalUI(img.id)}
                  disabled={
                    img.tipo === "principal" || img.status === "uploading"
                  }
                >
                  Hacer principal (UI)
                </Button>

                <Button
                  type="button"
                  variant="outline"
                  onClick={() => moveUI(img.id, -1)}
                  disabled={
                    img.tipo === "principal" || img.status === "uploading"
                  }
                  title="Subir"
                >
                  ↑
                </Button>

                <Button
                  type="button"
                  variant="outline"
                  onClick={() => moveUI(img.id, 1)}
                  disabled={img.status === "uploading"}
                  title="Bajar"
                >
                  ↓
                </Button>

                <Button
                  type="button"
                  variant="destructive"
                  onClick={() => remove(img)}
                  disabled={img.status === "uploading" || busy}
                >
                  Eliminar
                </Button>
              </div>

              <div className="text-xs text-muted-foreground">
                Orden(UI): {img.orden} • Tipo(UI): {img.tipo}{" "}
                {img.imagenId ? "• BD" : "• Local"}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-sm text-muted-foreground">
          Aún no hay imágenes.
        </div>
      )}
    </div>
  );
}
